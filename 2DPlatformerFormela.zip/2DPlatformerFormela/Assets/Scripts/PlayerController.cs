using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header("Movement parameters")]
    [Range(0.01f, 20.0f)] [SerializeField] private float moveSpeed = 0.1f;
    [SerializeField] public float jumpForce = 6.0f; //[Space(10)]
    [SerializeField] private LayerMask groundLayer;

    private Rigidbody2D rigidBody;
    private static float rayLength = 0.2f;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Awake()
    {
        rigidBody = GetComponent<Rigidbody2D>();        
    }

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
            transform.Translate(moveSpeed * Time.deltaTime, 0.0f, 0.0f, Space.World);
        else if(Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
            transform.Translate(moveSpeed * -1 * Time.deltaTime, 0.0f, 0.0f, Space.World);

        if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Space))
            Jump();

        Debug.DrawRay(transform.position, (rayLength * Vector3.down), Color.white, 0.2f, false);
    }

    bool IsGrounded()
    {
        return Physics2D.Raycast(this.transform.position, Vector2.down, rayLength, groundLayer.value);
    }

    void Jump()
    {
        if(IsGrounded())
        {
            rigidBody.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
            Debug.Log("jumping");
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("LevelExit"))
            Debug.Log("Game over");
        else if (collision.CompareTag("LevelFall"))
            Debug.Log("Level Fall");
    }
}
