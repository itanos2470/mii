using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header("Movement parameters")]
    [Range(0.01f, 20.0f)] [SerializeField] private float moveSpeed = 0.1f;
    [SerializeField] public float jumpForce = 6.0f; //[Space(10)]
    [SerializeField] private LayerMask groundLayer;

    private Rigidbody2D rigidBody;
    private static float rayLength = 0.2f;

    private Animator animator;
    private bool isRunning = false;
    private bool isFacingRight = true;
    Vector2 spawnPosition;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Awake()
    {
        rigidBody = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        spawnPosition = transform.position;
    }

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(GameManager.instance.currentGameState == GameState.GAME)
        {
            isRunning = false;
            if(Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
            {
                if (!isFacingRight)
                    FlipX();
                transform.Translate(moveSpeed * Time.deltaTime, 0.0f, 0.0f, Space.World);
                isRunning = true;
            }
            else if(Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
            {
                if (isFacingRight)
                    FlipX();
                transform.Translate(moveSpeed * -1 * Time.deltaTime, 0.0f, 0.0f, Space.World);
                isRunning = true;
            }

            if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Space))
                Jump();

            animator.SetBool("isGrounded", IsGrounded());
            animator.SetBool("isRunning", isRunning);
            Debug.DrawRay(transform.position, (rayLength * Vector3.down), Color.white, 0.2f, false);
        }
    }

    bool IsGrounded()
    {
        return Physics2D.Raycast(this.transform.position, Vector2.down, rayLength, groundLayer.value);
    }

    void Jump()
    {
        if(IsGrounded())
        {
            rigidBody.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        }
    }

    private void FlipX()
    {
        isFacingRight = !isFacingRight;
        Vector3 scale = transform.localScale;
        scale.x *= -1;
        transform.localScale = scale;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("LevelExit"))
            Debug.Log("Game over");
        else if (collision.CompareTag("LevelFall"))
            Debug.Log("Level Fall");
        else if (collision.CompareTag("Bonus"))
        {
            GameManager.instance.AddPoints(5);
            collision.gameObject.SetActive(false);
        }
        else if(collision.CompareTag("Enemy"))
        {
            if (transform.position.y > collision.gameObject.transform.position.y)
                Debug.Log("Killed an enemy");
            else
            {
                transform.position = spawnPosition;
                Debug.Log("You are dead");
            }
        }
    }
}
