using UnityEngine;
using System.Collections;

public class EnemyController : MonoBehaviour
{
    [Header("Movement parameters")]
    [Range(0.01f, 20.0f)] [SerializeField] private float moveSpeed = 0.1f;
    [SerializeField] private float moveRange = 1.0f;

    private Animator animator;
    private bool isFacingRight = false;
    float startPositionX;
    bool isMovingRight = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Awake()
    {
        animator = GetComponent<Animator>();
        startPositionX = this.transform.position.x;
    }

    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if(isMovingRight)
        {
            if (this.transform.position.x <= startPositionX + moveRange)
                MoveRight();
            else
            {
                FlipX();
                MoveLeft();
            }
        }
        else
        {
            if (this.transform.position.x >= startPositionX - moveRange)
                MoveLeft();
            else
            {
                FlipX();
                MoveRight();
            }
        }
    }

    private void MoveRight()
    {
        isMovingRight = true;
        transform.Translate(moveSpeed * Time.deltaTime, 0.0f, 0.0f, Space.World);
    }

    private void MoveLeft()
    {
        isMovingRight = false;
        transform.Translate(moveSpeed * -1 * Time.deltaTime, 0.0f, 0.0f, Space.World);
    }

    private void FlipX()
    {
        isFacingRight = !isFacingRight;
        Vector3 scale = transform.localScale;
        scale.x *= -1;
        transform.localScale = scale;
    }

    IEnumerator KillOnAnimationEnd()
    {
        yield return new WaitForSeconds(.3f);
        gameObject.SetActive(false);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            if(collision.gameObject.transform.position.y > transform.position.y)
            {
                animator.SetBool("isDead", true);
                StartCoroutine(KillOnAnimationEnd());
            }
        }
    }
}
